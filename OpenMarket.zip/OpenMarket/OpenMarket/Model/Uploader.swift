//
//  ProductJSONDecoder.swift
//  OpenMarket
//
//  Created by 임리나 on 2021/01/25.
//

import Foundation

struct Uploader {
    static func uploadData(by httpMethod: HTTPMethod, product: Product, specificNumer number: Int? = nil, completionHandler: @escaping (Result<Any, StringFormattingError>) -> ()){
        guard var urlRequest = URLRequestManager.makeURLRequest(for: httpMethod, specificNumer: number) else {
            completionHandler(.failure(.wrongURLRequest))
            return
        }
        
        urlRequest.httpBody = encoder(data: product)
        
        OpenMarketAPIManager.startLoad(urlRequest: urlRequest, specificNumer: number) { result in
            switch result {
            case .success(let data):
                completionHandler(.success(data))
            case .failure(let error):
                completionHandler(.failure(error))
            }
        }
    }
    
    static func encoder(data: Product) -> Data? {
        do {
            let encodedData = try JSONEncoder().encode(data)
            return encodedData
        } catch {
            return nil
        }
    }
}
