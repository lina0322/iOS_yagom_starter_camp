//
//  URLRequestManager.swift
//  OpenMarket
//
//  Created by 임리나 on 2021/01/27.
//

import Foundation

enum HTTPMethod: CustomStringConvertible {
    case get
    case post
    case put
    case patch
    case delete
    
    var description: String {
        switch self {
        case .get:
            return "GET"
        case .post:
            return "POST"
        case .put:
            return "PUT"
        case .patch:
            return "PATCH"
        case .delete:
            return "DELETE"
        }
    }
}

enum APIType: CustomStringConvertible {
    case page
    case product
    
    var description: String {
        switch self {
        case .page:
            return "items/"
        case .product:
            return "item/"
        }
    }
}

struct URLRequestManager {
    private static let baseURL = "https://camp-open-market.herokuapp.com/"

    static func makeURLRequest(for httpMethod: HTTPMethod, about type: APIType = .product, specificNumer number: Int?) -> URLRequest? {
        var absoluteURL: String
        if let number = number {
            absoluteURL = "\(baseURL)\(type)\(number)/"
        } else {
            absoluteURL = "\(baseURL)\(type)/"
        }
        
        guard let url = URL(string: absoluteURL) else {
            debugPrint(StringFormattingError.wrongURL)
            return nil
        }
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "\(httpMethod)"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        return urlRequest
    }
}

